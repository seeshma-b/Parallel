#ifndef UTILS_H
#define UTILS_H

#include <random>

// Generate a random doubles b/w min and max
double randomDouble(double min, double max);

#endif // UTILS_H
